(() => {
  // More robust and accurate Sales Navigator scraping
  function scrapeVisible() {
    // Check if we're on a list view page (as shown in the screenshot)
    const isListView = document.querySelector('table.lists-table') !== null;
    const leads = [];
    
    if (isListView) {
      // Target table rows for list view
      const rows = document.querySelectorAll('table.lists-table tbody tr');
      console.log(`Found ${rows.length} leads in list view`);
      
      rows.forEach(row => {
        try {
          // Extract name and profile link
          const nameCell = row.querySelector('td.name-cell');
          const nameLink = nameCell?.querySelector('a');
          const fullName = nameLink?.querySelector('span')?.innerText.trim() || '';
          const profileUrl = nameLink?.href ? `https://www.linkedin.com${nameLink.getAttribute('href').split('?')[0]}` : '';
          
          // Extract position/title
          const positionEl = nameCell?.querySelector('div[data-anonymize="job-title"]');
          const position = positionEl?.innerText.trim() || '';
          
          // Extract company name from the company column
          const companyCell = row.querySelector('td.company-cell a') || row.querySelector('td:nth-child(2)');
          const company = companyCell?.innerText.trim() || '';
          
          // Get location from the location column if it exists
          const locationCell = row.querySelector('td.location-cell') || row.querySelector('td:nth-child(3)');
          const location = locationCell?.innerText.trim() || '';
          
          // Split name into first/last
          let firstName = '';
          let lastName = '';
          
          if (fullName) {
            const nameParts = fullName.split(' ');
            firstName = nameParts[0] || '';
            lastName = nameParts.slice(1).join(' ') || '';
          }
          
          leads.push({
            firstName,
            lastName,
            fullName,
            position,
            company,
            profileUrl,
            location,
            industry: '', // Industry might not be directly available in the list view
            timestamp: new Date().toISOString()
          });
        } catch (e) {
          console.error('Error scraping list item:', e);
        }
      });
    } else {
      // Fall back to original search results scraping logic
      const items = document.querySelectorAll('li.search-results__result-item, div.entity-result__item');
      console.log(`Found ${items.length} leads in search results`);
      
      items.forEach(item => {
        try {
          // Extract name and link (these selectors work for both list and search views)
          const linkEl = item.querySelector('a[data-control-name="view_profile"], a.app-aware-link[href*="/in/"]');
          const nameEl = item.querySelector('.result-lockup__name, .artdeco-entity-lockup__title span[aria-hidden="true"]');
          const titleEl = item.querySelector('.result-lockup__highlight-keyword, .artdeco-entity-lockup__subtitle');
          const companyEl = item.querySelector('.result-lockup__position-company, .artdeco-entity-lockup__subtitle:nth-child(2)');
          const locationEl = item.querySelector('.result-lockup__misc-item, .artdeco-entity-lockup__caption');
          
          // Industry isn't directly available in Sales Navigator list views, but sometimes in the full profile
          const industryEl = item.querySelector('.industry-tag, [data-control-name="industry"]');
          
          // Extract URL from profile link
          const profileUrl = linkEl?.href || '';
          
          // Clean the LinkedIn URL to remove tracking parameters
          const cleanUrl = profileUrl.split('?')[0];
          
          // Extract full name and split into first/last
          const fullName = nameEl?.innerText.trim() || '';
          let firstName = '';
          let lastName = '';
          
          if (fullName) {
            const nameParts = fullName.split(' ');
            firstName = nameParts[0] || '';
            lastName = nameParts.slice(1).join(' ') || '';
          }

          leads.push({
            firstName,
            lastName,
            fullName,
            position: titleEl?.innerText.trim() || '',
            company: companyEl?.innerText.trim() || '',
            profileUrl: cleanUrl,
            location: locationEl?.innerText.trim() || '',
            industry: industryEl?.innerText.trim() || '',
            timestamp: new Date().toISOString()
          });
        } catch (e) {
          console.error('Error scraping item:', e);
        }
      });
    }
    
    console.log(`Total leads scraped: ${leads.length}`);
    return leads;
  }

  // Function to scroll and wait
  function smoothScroll(distance) {
    window.scrollBy({
      top: distance,
      behavior: 'smooth'
    });
    
    // Return true to acknowledge the scroll happened
    return true;
  }

  // Function to check if we've reached the bottom of the page
  function isAtBottom() {
    return window.innerHeight + window.scrollY >= document.body.scrollHeight - 200;
  }

  // Expose functions to be called from background script
  window.CaptelyScraper = {
    scrapeVisible,
    smoothScroll,
    isAtBottom
  };
  
  // Let the background script know we're ready
  console.log("Captely Sales Navigator Scraper initialized");
})();
  