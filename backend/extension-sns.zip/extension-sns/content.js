// Injects a "Scraper" button into Sales Navigator
(function injectButton() {
  // Add the button after a short delay to ensure the page has loaded
  setTimeout(() => {
    // Look for UI controls in both search results and list views
    const toolPanel = document.querySelector('.search-results-container__controls') || 
                      document.querySelector('.lists-page-header__title-container') ||
                      document.querySelector('.artdeco-tab-primary-group');
                      
    if (!toolPanel || document.getElementById('captely-scrape-btn')) return;

    // Create "Scrape" button
    const btn = document.createElement('button');
    btn.id = 'captely-scrape-btn';
    btn.textContent = 'Scrape';
    btn.style = 'margin-left:8px;padding:4px 8px;background:#0073b1;color:#fff;border:none;border-radius:4px;cursor:pointer;';
    btn.onclick = () => chrome.runtime.sendMessage({ action: 'startScraping' });
    
    // In list view, create a container for the button to align it properly
    const isListView = document.querySelector('table.lists-table') !== null;
    if (isListView) {
      const buttonContainer = document.createElement('div');
      buttonContainer.style = 'display:inline-block;margin-left:10px;';
      buttonContainer.appendChild(btn);
      toolPanel.appendChild(buttonContainer);
    } else {
      toolPanel.appendChild(btn);
    }
    
    console.log('Captely scrape button injected for ' + (isListView ? 'list view' : 'search results'));
  }, 2000);
  
  // Re-attempt injection when page navigation occurs (LinkedIn is a SPA)
  const observer = new MutationObserver((mutations) => {
    // If we don't have a button yet, try again
    if (!document.getElementById('captely-scrape-btn')) {
      setTimeout(() => injectButton(), 2000);
    }
  });
  
  // Observe changes to URL and page content
  observer.observe(document.body, { childList: true, subtree: true });
})();
