# services/enrichment-worker/app/__init__.py
# package marker for your tasks; no code needed here
